//
//  MCIVASSDKManager.h
//  MCIVASSDK
//
//  Created by Hooman Sanatkar on 2019-03-19.
//  Copyright © 2019 Moj. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


@interface MCIVASSDKManager : NSObject{
    
}
+ (id)shareadManager ;
-(void)setupWithSDP:(NSString *)sdp serviceKey:(NSString *)serviceKey theme:(NSString *)theme;
-(void)subscribeMeWithViewController:(UIViewController *)viewController SDP:(NSString *)sdp serviceKey:(NSString *)serviceKey theme:(NSString *)theme;

@end

