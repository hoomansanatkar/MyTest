//
//  MCIVASSDK.h
//  MCIVASSDK
//
//  Created by Hooman Sanatkar on 2019-03-17.
//  Copyright © 2019 Moj. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MCIVASSDK/MCIVASSDKManager.h>

//! Project version number for MCIVASSDK.
FOUNDATION_EXPORT double MCIVASSDKVersionNumber;

//! Project version string for MCIVASSDK.
FOUNDATION_EXPORT const unsigned char MCIVASSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MCIVASSDK/PublicHeader.h>

